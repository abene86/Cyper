#ifndef WRITEFILE_H
#define WRITEFILE_H


void inputFileNameCh2(char filename[][50]);
void openWriteOnFile(char filename[][50]);
    void writeDecodedFile(FILE *outfile);

#endif