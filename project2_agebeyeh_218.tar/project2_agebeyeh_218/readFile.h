#ifndef READFILE_H
#define READFILE_H

void inputFileName(char filename[][50]);
void openreadFromFile(char filename[][50]);

extern char filename[3][50];

#endif